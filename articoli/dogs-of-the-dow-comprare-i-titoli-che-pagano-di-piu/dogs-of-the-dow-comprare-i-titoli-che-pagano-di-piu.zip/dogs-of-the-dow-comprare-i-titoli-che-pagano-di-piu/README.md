# Dogs of the Dow: comprare i titoli che pagano di più

L'articolo completo, con risultati e grafici, è sul blog: [Dogs of the Dow: comprare i titoli che pagano di più](https://ticker-fight.blogspot.com/2026/11/dogs-of-dow-comprare-i-titoli-che.html).

## Cosa c'è in questa cartella

```
dogs-of-the-dow-comprare-i-titoli-che-pagano-di-piu/
├── requirements.txt   librerie Python, versioni fissate
└── flusso/
    ├── 01_scarica_dati.py
    ├── 02_backtest_e_test.py
    ├── 03_grafici.py
    ├── config.py
    ├── motore.py
    └── verifica_motore.py
```

## Come si rifà

```bash
cd articoli/dogs-of-the-dow-comprare-i-titoli-che-pagano-di-piu
python -m venv .venv
source .venv/bin/activate          # su Windows: .venv\Scripts\activate
pip install -r requirements.txt

python flusso/verifica_motore.py
python flusso/01_scarica_dati.py
python flusso/02_backtest_e_test.py
python flusso/03_grafici.py
```

Il primo passo controlla il motore di simulazione su dati inventati (se c'è); poi si scaricano i prezzi da Yahoo Finance in `dati/`, si calcolano i risultati in `risultati/` e i grafici in `figure/`. Parametri, ipotesi e seme dei sorteggi sono in `flusso/config.py`. Yahoo a volte corregge i prezzi storici: con dati scaricati in un altro giorno i numeri possono differire di poco da quelli dell'articolo.
